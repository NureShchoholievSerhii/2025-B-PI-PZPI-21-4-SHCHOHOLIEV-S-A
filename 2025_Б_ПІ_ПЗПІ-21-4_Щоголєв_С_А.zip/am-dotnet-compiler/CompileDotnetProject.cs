using System.Diagnostics;
using System.IO.Compression;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace am_dotnet_compiler;

public class CompileDotnetProject(ILogger<CompileDotnetProject> logger)
{
    private readonly ILogger<CompileDotnetProject> _logger = logger;

    [Function("compile-dotnet-project")]
    public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req)
    {
        _logger.LogInformation("Dotnet project compilation request received.");

        try
        {
            var tempPath = Path.GetTempPath();
            InstallDotnetSdk(tempPath);

            var tempZipPath = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid()}.zip");
            using (var fileStream = new FileStream(tempZipPath, FileMode.Create, FileAccess.Write))
            {
                await req.Body.CopyToAsync(fileStream);
            }
            _logger.LogInformation($"ZIP file saved to: {tempZipPath}");

            var extractionPath = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString());
            ZipFile.ExtractToDirectory(tempZipPath, extractionPath);
            _logger.LogInformation($"ZIP file extracted to: {extractionPath}");

            var projectFile = Directory.GetFiles(extractionPath, "*.csproj", SearchOption.AllDirectories);
            if (projectFile.Length == 0)
            {
                throw new Exception("No .csproj file found in the ZIP file.");
            }
            var projectFilePath = projectFile[0];
            _logger.LogInformation($"Found project file: {projectFilePath}");

            var (succeded, output, logs) = RunDotnetBuild(projectFilePath);

            var response = new CompilationResponse
            {
                Succeeded = succeded,
                Output = output,
                Logs = logs
            };

            return succeded ? new OkObjectResult(response) : new BadRequestObjectResult(response);
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error: {ex.Message}");
            return new BadRequestObjectResult(new CompilationResponse { Error = ex.Message });
        }
    }

    private static (bool Success, string Output, string Logs) RunDotnetBuild(string projectFilePath)
    {
        var startInfo = new ProcessStartInfo
        {
            FileName = "dotnet",
            Arguments = $"build \"{projectFilePath}\"",
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        using var process = new Process { StartInfo = startInfo };
        var outputBuilder = new StringBuilder();
        var errorBuilder = new StringBuilder();

        process.OutputDataReceived += (sender, args) => outputBuilder.AppendLine(args.Data);
        process.ErrorDataReceived += (sender, args) => errorBuilder.AppendLine(args.Data);

        process.Start();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        process.WaitForExit();

        var success = process.ExitCode == 0;
        var output = outputBuilder.ToString();
        var logs = errorBuilder.ToString();

        return (success, output, logs);
    }

    private static void InstallDotnetSdk(string installPath)
    {
        var scriptUrl = "https://dot.net/v1/dotnet-install.sh";
        var installScriptPath = Path.Combine(installPath, "dotnet-install.sh");

        // Download the installation script
        using (var client = new HttpClient())
        {
            var scriptData = client.GetByteArrayAsync(scriptUrl).Result;
            File.WriteAllBytes(installScriptPath, scriptData);
        }

        // Make the script executable
        var chmodProcess = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = "chmod",
                Arguments = $"+x {installScriptPath}",
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            }
        };
        chmodProcess.Start();
        chmodProcess.WaitForExit();

        if (chmodProcess.ExitCode != 0)
        {
            throw new Exception("Failed to make dotnet-install.sh executable.");
        }

        // Run the installation script for the SDK
        var installProcess = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = "bash",
                Arguments = $"{installScriptPath} --install-dir {installPath}",
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            }
        };
        installProcess.Start();
        installProcess.WaitForExit();

        if (installProcess.ExitCode != 0)
        {
            throw new Exception($"Failed to install .NET SDK. Error: {installProcess.StandardError.ReadToEnd()}");
        }

        // Update the PATH environment variable
        Environment.SetEnvironmentVariable("PATH", $"{installPath}:{Environment.GetEnvironmentVariable("PATH")}");
    }

    public class CompilationResponse
    {
        public bool Succeeded { get; set; }

        public string? Output { get; set; }

        public string? Logs { get; set; }

        public string? Error { get; set; }
    }
}
