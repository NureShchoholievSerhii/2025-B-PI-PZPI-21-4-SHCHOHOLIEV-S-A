namespace AssetsManagerApi.Api.Models;

public class ResetPasswordRequestModel
{
    public string Email { get; set; }
}
