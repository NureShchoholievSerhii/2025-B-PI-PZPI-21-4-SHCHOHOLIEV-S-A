﻿using AssetsManagerApi.Domain.Entities;

namespace AssetsManagerApi.Application.IRepositories;
public interface ICodeFilesRepository : IBaseRepository<CodeFile>
{
}
