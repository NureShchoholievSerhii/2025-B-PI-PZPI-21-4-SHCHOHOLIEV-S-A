﻿using AssetsManagerApi.Domain.Entities;

namespace AssetsManagerApi.Application.IRepositories;

public interface ICompaniesRepository : IBaseRepository<Company>
{
}
