﻿namespace AssetsManagerApi.Application.Models.Identity;

public class TokensModel
{
    public string AccessToken { get; set; }

    public string RefreshToken { get; set; }
}