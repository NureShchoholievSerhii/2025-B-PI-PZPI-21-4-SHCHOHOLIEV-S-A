namespace AssetsManagerApi.Application.Models.Operations;

public class CompilationResult
{
    public string? Error { get; set; }
}
