﻿namespace AssetsManagerApi.Application.Models.Operations
{
    public class TagFilterModel
    {
        public string? SearchString { get; set; }
    }
}
