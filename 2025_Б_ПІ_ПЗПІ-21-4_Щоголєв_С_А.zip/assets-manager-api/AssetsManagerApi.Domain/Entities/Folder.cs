﻿namespace AssetsManagerApi.Domain.Entities;

public class Folder : FileSystemNode {}
