﻿namespace AssetsManagerApi.Domain.Enums;

public enum FileType
{
    Folder = 0,
    CodeFile = 1
}
